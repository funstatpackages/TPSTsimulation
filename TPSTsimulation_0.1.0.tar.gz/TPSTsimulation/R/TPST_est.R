TPST_est <- function(B, Q2, K, Yi, lambda) { 
  library(matrixcalc)
  n <- length(Yi)
  W <- B %*% Q2
  WW <- t(W) %*% W
  WY <- t(W) %*% Yi
  D <- t(Q2) %*% K %*% Q2
  nq <- dim(Q2)[2]
  Iq <- diag(nq)
  
  # if (!is.positive.definite(as.matrix(WW), tol=1e-12)) {  # original
  
  # if ((!is.symmetric.matrix(as.matrix(WW))) | 
  #     (!is.positive.definite(as.matrix(WW), tol = 1e-12))) { # for PC only
  #   WW <- WW + diag(nq) * (1e-12)
  # }
  
  
   if (is.symmetric.matrix(as.matrix(WW))) { # for 1P and 2P: can work on server
     if (!is.positive.definite(as.matrix(WW))) {
       WW <- WW + diag(nq) * (1e-12) #(1e-6)
     }
   } else {
     WW <- WW + diag(nq) * (1e-12)
   }
  
  Ainv <- chol(WW);
  A <- solve(t(Ainv), Iq)
  ADA <- A %*% D %*% t(A)
  C <- matrix(Re(eigen(as.matrix(ADA))$values), ncol = 1)
  nl <- length(lambda)
  
  sse_all <- NULL; df_all <- NULL; gcv_all <- NULL; bic_all <- NULL; 
  theta_all <- NULL; gamma_all <- NULL;
  
  for (il in 1:nl) {
    Lam <- lambda[il]
    Dlam <- Lam * D
    Winv <- solve((WW + Dlam), Iq)
    theta <- Winv %*% WY;
    theta_all <- cbind(theta_all, theta)
    gamma <- Q2 %*% theta
    gamma_all <- cbind(gamma_all, gamma)
    Yhat <- W %*% theta
    sse <- sum((Yi - Yhat)^2)
    sse_all <- cbind(sse_all, sse) 
    df <- sum(1 / (1 + C * Lam))
    df_all <- cbind(df_all, df)
    gcv <- n * sse / (n - df)^2
    gcv_all <- cbind(gcv_all, gcv)
    bic <- log(sse / n) + df * log(n) / n
    bic_all <- cbind(bic_all, bic)
  }
  gcv <- min(gcv_all)
  lam_ind <- which.min(gcv_all)
  lamc <- lambda[lam_ind];
  theta <- matrix(theta_all[ , lam_ind], ncol=1)
  gamma <- matrix(gamma_all[ , lam_ind], ncol=1)
  df <- df_all[lam_ind]
  sse <- sse_all[lam_ind]
  bic <- bic_all[lam_ind]
  Yhat <- W %*% theta
  
  TPST_est.list <- list(theta = theta, gamma = gamma, Yhat = Yhat, sse = sse, lamc = lamc, gcv = gcv, bic = bic)
  
  return(TPST_est.list)
    
}