findNabr <- function(Th0, V, Th, TV, nl) {
  TV.full <- as.matrix(TV)
  I_th <- matrix(Th0, ncol = 1);
  V1 <- NULL; Th1 <- NULL;
  for (il in 1:nl) {
    k <- length(I_th)
    J <- NULL
    for (j in 1:k) {
      J1 <- matrix(which(TV.full[, I_th[j, 1]] != 0, arr.ind = TRUE), ncol = 1)
      J <- rbind(J, J1)
    }
    V2 <- Th[J, ]
    I_th <- matrix(V2, ncol = 1)
    V1 <- rbind(V1, I_th)
    Th1 <- rbind(Th1, J)
  }
  V1 <- matrix(sort(unique(V1)), ncol = 1)
  I_th <- V1
  V1 <- V[I_th, ]
  Th1 <- Th[matrix(sort(unique(Th1)), ncol = 1), ]
  nT1 <- dim(Th1)[1]
  T1 <- matrix(NA, nrow = nT1, ncol = 4)
  for (i in 1:nT1) {
    j <- Th1[i, 1]; nj <- which(I_th == j); T1[i,1] <- nj;
    j <- Th1[i, 2]; nj <- which(I_th == j); T1[i,2] <- nj;
    j <- Th1[i, 3]; nj <- which(I_th == j); T1[i,3] <- nj;
    j <- Th1[i, 4]; nj <- which(I_th == j); T1[i,4] <- nj;
  }
  j <- Th0[1, 1]; nj <- which(I_th == j); Th0[1, 1] <- nj;
  j <- Th0[1, 2]; nj <- which(I_th == j); Th0[1, 2] <- nj;
  j <- Th0[1, 3]; nj <- which(I_th == j); Th0[1, 3] <- nj;
  j <- Th0[1, 4]; nj <- which(I_th == j); Th0[1, 4] <- nj;
  
  findNabr.list <- list(V1 = V1, Th1 = Th1, Th0 = Th0, I_th = I_th)
  return(findNabr.list)
}