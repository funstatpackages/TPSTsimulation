tpst.npd.global <- function(V, Th, d, r, x0, y0, z0, sig, missing, nSIM.start, nSIM, ss) {
  nx_pop = length(x0);
  ny_pop = length(y0);
  nz_pop = length(z0);
  Npop = nx_pop * ny_pop * nz_pop
  
  Zpop <- expand.grid(x0, y0, z0)
  Bpop.all <- basis3D(V, Th, d, r, Zpop, PL.worker.parLapply = 0)
  ind.pop <- Bpop.all$ind.inside   
  Bpop <- Bpop.all$B
  Zpop.inside <- Zpop[ind.pop, ]
  
  gc()

  pop <- dataGeneratorHS(Zpop, ind.pop, sig, 0)
  Ypop <- pop$Y
  mupop <- pop$mu
  psnr = pop$psnr
  pop <- cbind(Ypop, mupop, Zpop)
  
  K <- energyM3D(V, Th, d)
  H <- smoothness3D(V, Th, d, r)
  H.full <- as.matrix(H)
  Q2 <- qrH(H.full)
  
  gc()

  HH <-  H %*% t(H)
  HHinv <- solve((HH + (1e-12) * diag(nrow(HH))), diag(nrow(HH)))
  PH <- t(H) %*% HHinv %*% H 
  
  # candidates for roughness penalty parameter;
  nT <- nrow(Th)
  npara <- choose((d + 3), 3)
  index <- seq(-6, 4, by = 1);
  lambda <- 10^index
  
  gc()

  # main iteration
  mise.global.all <- NULL
  mise.globals.all <- NULL
  mspe.global.all <- NULL
  mspe.globals.all <- NULL
  miss.rate.all = NULL

  mise.global.matrix <- matrix(NaN, nSIM, 4)
  mspe.global.matrix <- matrix(NaN, nSIM, 4)
  miss.rate.matrix <- matrix(NaN, nSIM, 2)

  for (iter in (nSIM.start):(nSIM.start + nSIM - 1)) {
    set.seed(iter)
    xx <- runif(ss * 2, -0.85, 3.35); 
    yy <- runif(ss * 2, -0.85, 0.85); 
    zz <- runif(ss * 2, -0.45, 0.45);
    Z <- cbind(xx, yy, zz)
    
    B.sam <- basis3D(V, Th, d, r, Z, PL.worker.parLapply = 0)
    
    gc()

    ind.sam <- sort(B.sam$ind.inside)
    sam <- dataGeneratorHS(Z, ind.sam, sig, missing)
    Y <- sam$Y
    mu = sam$mu
    ind.nna = 1:(ss * 2)
    ind.nna = ind.nna[!is.na(mu)]
    ind = intersect(ind.sam, ind.nna)
    ind = sample(ind, ss, replace = FALSE); ind = sort(ind);
    Y = Y[ind]
    Z = Z[ind, ]
    indi = 1:ss; indi = indi[!is.na(Y)];
    Yi = Y[indi]
    Zi = Z[indi, ]
    miss.rate.all = c(miss.rate.all, 100 - length(indi)/ss*100)
    # miss.rate.all
    miss.rate.matrix[iter - nSIM.start + 1, 1] <- iter
    miss.rate.matrix[iter - nSIM.start + 1, 2] <- 100 - length(indi)/ss*100

    B.sam <- basis3D(V, Th, d, r, Zi, PL.worker.parLapply = 0)

    gc()

    
    # Global Estimation
    mfit.global <- TPST_est(B.sam$B, Q2, K, Yi, lambda)
    gamma.global <- mfit.global$gamma
    lamc <- mfit.global$lamc
    
    # Prediction;
    Ypred.global = rep(NA, length(Ypop))
    Ypred.global[ind.pop] <- Bpop %*% gamma.global
    mise.global <- mean((mupop - Ypred.global)^2, na.rm = TRUE)
    mise.global.all <- cbind(mise.global.all, mise.global) 
    mspe.global <- mean((Ypop - Ypred.global)^2, na.rm = TRUE)
    mspe.global.all <- c(mspe.global.all, mspe.global)
    
    ##################
    gamma.globals <- gamma.global - PH %*% gamma.global
    Ypred.globals = rep(NA, length(Ypop))
    Ypred.globals[ind.pop] <- Bpop %*% gamma.globals
    mise.globals <- mean((mupop - Ypred.globals)^2, na.rm = TRUE)
    mise.globals.all <- c(mise.globals.all, mise.globals) 
    mspe.globals <- mean((Ypop - Ypred.globals)^2, na.rm = TRUE)
    mspe.globals.all <- c(mspe.globals.all, mspe.globals)

    mise.global.matrix[iter - nSIM.start + 1, 1] = iter
    mise.global.matrix[iter - nSIM.start + 1, 2] = mise.global
    mise.global.matrix[iter - nSIM.start + 1, 3] = mise.globals
    mise.global.matrix[iter - nSIM.start + 1, 4] = min(mise.global, mise.globals)
    
    mspe.global.matrix[iter - nSIM.start + 1, 1] = iter
    mspe.global.matrix[iter - nSIM.start + 1, 2] = mspe.global
    mspe.global.matrix[iter - nSIM.start + 1, 3] = mspe.globals
    mspe.global.matrix[iter - nSIM.start + 1, 4] = min(mspe.global, mspe.globals)

  }
  result.list <- list(ave.mise = mean(mise.global.matrix[, 4]), ave.mspe = mean(mspe.global.matrix[, 4]), ave.miss.rate = mean(miss.rate.matrix[, 2]), psnr = psnr, sample_size = ss, mise.global.matrix = mise.global.matrix, mspe.global.matrix = mspe.global.matrix, miss.rate.matrix = miss.rate.matrix)
  return(result.list)
}
