tpst.npd.master.parLapply <- function(V, Th, d, r, x0, y0, z0, sig, missing, nSIM.start, nSIM, pmethod, ss) {
  nx_pop = length(x0);
  ny_pop = length(y0);
  nz_pop = length(z0);
  Npop = nx_pop * ny_pop * nz_pop
  
  Zpop <- expand.grid(x0, y0, z0)
  
  Bpop.all <- basis3D(V, Th, d, r, Zpop, PL.worker.parLapply = 1)
  ind.pop <- Bpop.all$ind.inside
  Bpop <- Bpop.all$B
  Zpop.inside <- Zpop[ind.pop, ]
  
   gc()

  pop <- dataGeneratorHS(Zpop, ind.pop, sig, 0)
  Ypop <- pop$Y
  mupop <- pop$mu
  psnr = pop$psnr
  pop <- cbind(Ypop, mupop, Zpop)
  
  K <- energyM3D(V, Th, d)
  H <- smoothness3D(V, Th, d, r) 
  H.full <- as.matrix(H)
  Q2 <- qrH(H.full)

   gc()

  HH <-  H %*% t(H)
  HHinv <- solve((HH + (1e-12) * diag(nrow(HH))), diag(nrow(HH)))
  PH <- t(H) %*% HHinv %*% H 
  
  # candidates for roughness penalty parameter;
  nT <- nrow(Th)
  npara <- choose((d + 3), 3)
  index <- seq(-6, 4, by = 1);
  lambda <- 10^index
  
   gc()

  # main iteration
  mise.ddc.all <- matrix(NaN, nSIM, 3)
  mise.ddcs.all <- NULL
  mspe.ddc.all <- NULL
  mspe.ddcs.all <- NULL
  miss.rate.all <- NULL
  mise.ddc.matrix <- matrix(NaN, nSIM, 4)
  mspe.ddc.matrix <- matrix(NaN, nSIM, 4)
  miss.rate.matrix <- matrix(NaN, nSIM, 2)
  
  for (iter in (nSIM.start):(nSIM.start + nSIM - 1)) {
    set.seed(iter)
    xx <- runif(ss * 2, -0.85, 3.35); 
    yy <- runif(ss * 2, -0.85, 0.85); 
    zz <- runif(ss * 2, -0.45, 0.45);
    Z <- cbind(xx, yy, zz)
    
    B.sam <- basis3D(V, Th, d, r, Z, PL.worker.parLapply = 1)
    ind.sam <- sort(B.sam$ind.inside)
    sam <- dataGeneratorHS(Z, ind.sam, sig, missing)
    Y <- sam$Y
    mu = sam$mu
    ind.nna = 1:(ss * 2)
    ind.nna = ind.nna[!is.na(mu)]
    ind = intersect(ind.sam, ind.nna)
    ind = sample(ind, ss, replace = FALSE); ind = sort(ind);
    Y = Y[ind]
    Z = Z[ind, ]
    indi = 1:ss; indi = indi[!is.na(Y)];
    Yi = Y[indi]
    Zi = Z[indi, ]
    miss.rate.all = c(miss.rate.all, 100 - length(indi)/ss*100)
    miss.rate.matrix[iter - nSIM.start + 1, 1] <- iter
    miss.rate.matrix[iter - nSIM.start + 1, 2] <- 100 - length(indi)/ss*100
  
    B.sam <- basis3D(V, Th, d, r, Zi, PL.worker.parLapply = 1)
    
    # DDC Estimation
    thdata.list <- thdata(V, Th)
    TV.sparse <- thdata.list$TV.sparse
    gamma.ddcs <- matrix(0, nrow = npara, ncol = nT)
    
     gc()

    if (pmethod == 1) { ## mclapply
      pt.1 <- proc.time()[3]
      ns = 4 # ns = 1 for windows
      #system.time({
      results.all <- mclapply(1:nT,
                              FUN = tpst.worker.mclapply, mc.cores = ns,
                              V = V, Th = Th, TV.sparse = TV.sparse, 
                              d = d, r = r, Zi = Zi, Yi = Yi, lambda = lambda, 
                              npara = npara, mc.preschedule = FALSE)
      #})
      computing.parallel.time <- proc.time()[3] - pt.1
      
    } else {  ## parLapply 
      # Build PSOCK cluster in Windows 
      # makeCluster(cpu.cores, type = "FORK") in Linux
      pt.1 <- proc.time()[3]
      cpu.cores <- detectCores()
      cl <- makeCluster(cpu.cores)
      #cl <- makeCluster(cpu.cores, type = "FORK") #in Linux
      #cl <- makeForkCluster(cpu.cores)
      Ncl <- cl
      
      # load library(pracma) into all nodes 
      clusterEvalQ(cl, {
        library(pracma)
        library(parallel) # for pointLocation3D.parLapply.2
      })
      
      clusterEvalQ(cl, {
        source("basis3D.R")
        source("basis3DFns.R")
        source("energyM3D.R")
        source("energy3DFns.R")
        source("smoothness3D.R")
        source("smoothness3DFns.R")
        source("thdata.R")
        source("bary.R")
        source("qrH.R")
        source("TPST_est.R")
        source("findNabr.R")
        source("insideVT.R")
        source("pointLocation3D.worker.parLapply.R")
      })
      
      # Build global variables
      V <- V
      Th <- Th
      d <- d
      r <- r

      # Transfer variables into all nodes
      varlist <- c("V", "Th", "d", "r")
      clusterExport(cl, varlist, envir = .GlobalEnv)
      
      # Use global variables at all nodes nrow(Th)
      results.all <- parLapply(cl = cl, 1:nrow(Th), fun = tpst.npd.worker.parLapply, 
                               Zi = Zi, Yi = Yi, npara = npara, 
                               TV.sparse = TV.sparse, lambda = lambda, ss = ss)

      stopCluster(cl)
      computing.parallel.time <- proc.time()[3] - pt.1
      
       gc()
    }
    
    # combine results from workers ----
    for (i in 1:nrow(Th)) {
      gamma.ddcs[, i] <- results.all[[i]]
    }

    gamma.ddcs <- matrix(gamma.ddcs, ncol = 1)
    
    # Prediction;
    Ypred.ddcs = rep(NA, length(Ypop))
    Ypred.ddcs[ind.pop] <- Bpop %*% gamma.ddcs
    mise.ddcs <- mean((mupop - Ypred.ddcs)^2, na.rm = TRUE)
    mise.ddcs.all <- c(mise.ddcs.all, mise.ddcs) 
    mspe.ddcs <- mean((Ypop - Ypred.ddcs)^2, na.rm = TRUE)
    mspe.ddcs.all <- c(mspe.ddcs.all, mspe.ddcs) 
    
    gamma.ddc <- gamma.ddcs - PH %*% gamma.ddcs
    Ypred.ddc = rep(NA, length(Ypop))
    Ypred.ddc[ind.pop] <- Bpop %*% gamma.ddc
    mise.ddc <- mean((mupop - Ypred.ddc)^2, na.rm = TRUE)
    mise.ddc.all <- c(mise.ddc.all, mise.ddc) 
    mspe.ddc <- mean((Ypop - Ypred.ddc)^2, na.rm = TRUE)
    mspe.ddc.all <- c(mspe.ddc.all, mspe.ddc)
    
    mise.ddc.matrix[iter - nSIM.start + 1, 1] = iter
    mise.ddc.matrix[iter - nSIM.start + 1, 2] = mise.ddcs
    mise.ddc.matrix[iter - nSIM.start + 1, 3] = mise.ddc
    mise.ddc.matrix[iter - nSIM.start + 1, 4] = min(mise.ddcs,mise.ddc)
    
    mspe.ddc.matrix[iter - nSIM.start + 1, 1] = iter
    mspe.ddc.matrix[iter - nSIM.start + 1, 2] = mspe.ddcs
    mspe.ddc.matrix[iter - nSIM.start + 1, 3] = mspe.ddc
    mspe.ddc.matrix[iter - nSIM.start + 1, 4] = min(mspe.ddcs,mspe.ddc)
  }
  result.list <- list(ave.mise = mean(mise.ddc.matrix[, 4]), ave.mspe = mean(mspe.ddc.matrix[, 4]), ave.miss.rate = mean(miss.rate.matrix[, 2]), psnr = psnr, sample_size = ss, mise.ddc.matrix = mise.ddc.matrix, mspe.ddc.matrix = mspe.ddc.matrix, miss.rate.matrix = miss.rate.matrix)
  return(result.list)
}
