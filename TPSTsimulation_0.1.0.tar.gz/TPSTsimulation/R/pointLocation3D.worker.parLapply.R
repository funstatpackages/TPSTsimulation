pointLocation3D.worker.parLapply <- function(i, ind.VT_0, lam_0, tol.pl, Z, Th){
  for (j in nrow(Th):1) {
    A <- V[Th[j, 1], ]
    B <- V[Th[j, 2], ]
    C <- V[Th[j, 3], ]
    D <- V[Th[j, 4], ]
    Det.0 <- det(cbind(rbind(A, B, C, D),matrix(1, nrow = 4)))
    Det.1 <- det(cbind(rbind(Z[i, ], B, C, D), matrix(1, nrow = 4)))
    Det.2 <- det(cbind(rbind(A, Z[i, ], C, D), matrix(1, nrow = 4)))
    Det.3 <- det(cbind(rbind(A, B, Z[i, ], D), matrix(1, nrow = 4)))
    Det.4 <- det(cbind(rbind(A, B, C, Z[i, ]), matrix(1, nrow = 4)))
    
    if (Det.0 > 0) {
      if ((Det.1 > Det.0) | (Det.2 > Det.0) | (Det.3 > Det.0) | (Det.4 > Det.0)) {
        next
      } else if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
        ind.VT_0 <- j
        break
      } else if ((Det.1 < 0) & (abs(Det.1) <= tol.pl)) {
        if ((Det.2 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.2 < 0) & (abs(Det.2) <= tol.pl) & (Det.3 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl) & (Det.2 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.2 >= 0) & (Det.3 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.2 < 0) & (abs(Det.2) <= tol.pl)) {
        if ((Det.1 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl) & (Det.1 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.1 >= 0) & (Det.3 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl)) {
        if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.4 >= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.1 >= 0) & (Det.2 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl)) {
        if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.3 >= 0)) {
          ind.VT_0 <- j
          break
        }
      }
    } else if (Det.0 < 0){
      if ((abs(Det.1) >= abs(Det.0)) | (abs(Det.2) >= abs(Det.0)) | (abs(Det.3) >= abs(Det.0)) | (abs(Det.4) >= abs(Det.0))) {
        next
      } else if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
        ind.VT_0 <- j
        break
      } else if ((Det.1 > 0) & (Det.1 <= tol.pl)) {
        if ((Det.2 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.2 > 0) & (Det.2 <= tol.pl) & (Det.3 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.3 > 0) & (Det.3 <= tol.pl) & (Det.2 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.2 >= 0) & (Det.3 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.2 > 0) & (Det.2 <= tol.pl)) {
        if ((Det.1 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.3 > 0) & (Det.3 <= tol.pl) & (Det.1 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.1 >= 0) & (Det.3 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.3 > 0) & (Det.3 <= tol.pl)) {
        if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.4 <= 0)) {
          ind.VT_0 <- j
          break
        } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.1 >= 0) & (Det.2 >= 0)) {
          ind.VT_0 <- j
          break
        }
      } else if ((Det.4 > 0) & (Det.4 <= tol.pl)) {
        if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.3 <= 0)) {
          ind.VT_0 <- j
          break
        }
      }
    }
  }
  
  if (ind.VT_0 != "NaN") {
    lam_0[1, 1] <- Det.1 / Det.0
    lam_0[1, 2] <- Det.2 / Det.0
    lam_0[1, 3] <- Det.3 / Det.0
    lam_0[1, 4] <- Det.4 / Det.0
  }
  PL.results <- list(nT = nrow(Th), ind.VT_0 = ind.VT_0, lam_0 = lam_0)
  #PL.results.all <- list(r=r,tol.pl = tol.pl)
  return(PL.results)
}