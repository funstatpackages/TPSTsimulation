#' Test of Whether a Point Falls Inside of Tetrahedral Partition
#'
#' @importFrom pracma eps
#' @param V The \code{N} by three matrix of vertices of a tetrahedron, where \code{N} is the number of vertices. Each row is the coordinates for a vertex.
#' \cr
#' @param Th The tetrahedral partition matrix of dimension \code{nT} by four, where \code{nT} is the number of tetrahedrons in the partition. Each row is the indices of vertices in \code{V}.
#' \cr
#' @param Z The coordinates of dimension \code{n} by three. Each row is the 3D coordinates of a point.
#' \cr
#' @return A vector that indicates whether each observed point falls within the tetrahedral partition.
#'
#' @details This R program is modified based on the Matlab program written by Ming-Jun Lai from the University of Georgia.
#'
#' @export
#'
insideVT <- function (V, Th, Z) {
  nT <- nrow(Th)
  tol <- -eps(1)
  n <- nrow(Z)
  z1 <- Z[, 1]
  z2 <- Z[, 2]
  z3 <- Z[, 3]
  L <- HQbary(V, Th, z1, z2, z3)
  ind.inside <- matrix(0, nrow = n, ncol = 1)
  for (j in 1:nT) {
    I <- which(L[(j - 1) * 4 + 1, ] >= tol & L[(j - 1) * 4 + 2, ] >= tol & L[(j - 1) * 4 + 3, ] >= tol & L[(j - 1) * 4 + 4, ] >= tol)
    ind.inside[I] <- 1
  }
  return(ind.inside)
}
