# This function is used to calculate the bary centric coordinates
# Inputs:
# X: the evaluation point
# V: the coordinates of the vertices
# Outputs:
# Br <- [b1, b2, b3, b4]
bary <- function(X, V){
  VV <- rbind(V, rep(1, 4))
  XX <- c(X, 1)
  Br <- solve(VV, XX)
  bary.list <- list(Br = Br, VV = VV, XX = XX)
  return(bary.list)
}
# Example:
#V <- matrix(c(2, 1, 2, 3, 3, 3, 4, 3, 4, 5, 3, 4), nrow = 3, ncol = 4)
#X <- matrix(c(1, 1, 1), nrow = 3, ncol = 1)
#Bary(X, V)