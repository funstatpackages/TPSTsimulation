#' @importFrom Matrix sparseMatrix det
#' @importFrom pracma eps
#'
HQblkdiag <- function (A, cnt) {
  n <- dim(A)[1]
  m <- dim(A)[2]
  k <- length(cnt) - 1
  D <- matrix(0, nrow = n, ncol = (k * m))
  for (i in 1:k) {
    D[(cnt[i] + 1):cnt[i + 1], ((i - 1) * m + 1):(i * m)] = A[(cnt[i] + 1):cnt[i + 1], ];
  }
  return(D)
}
# Example:
# A <- matrix(c(1, 4, 7, 10, 2, 5, 8, 11, 3, 6, 9, 12), nrow = 4, ncol = 3)
# cnt <- matrix(c(1, 2, 3, 4), ncol = 1)
# HQblkdiag(A, cnt)

HQbary <- function (V, Th, X, Y, Z) {
  k <- dim(Th)[1]
  A <- t(Th);
  B <- V[A, ];
  One <- matrix(1, nrow = dim(B)[1], ncol = 1)
  C <- cbind(One, B)
  cnt <- 4 * matrix(c(0:k), ncol = 1)
  C <- HQblkdiag(C, cnt)
  C <- t(C)
  
  X <- matrix(X, ncol = 1)
  Y <- matrix(Y, ncol = 1)
  Z <- matrix(Z, ncol = 1)
  One <- matrix(1, nrow = 1, ncol = dim(X)[1])
  D <- rbind(One, t(X), t(Y), t(Z))
  D <- t(matrix(rep(t(D), k), nrow = dim(t(D))[1]))
  Lam <- solve(C, D)
  #View(Lam)
  return(Lam)
}
# Example:
# run eg1_main first
# X <- matrix(c(1, 2, 3), nrow = 1)
# Y <- matrix(c(4, 5, 6), nrow = 1)
# Z <- matrix(c(7, 8, 9), nrow = 1)
# HQbary(V, Th, X, Y, Z)

######################################################################
# pointLocation3D (Z, V, Th)
# Function: Find the index of tetrahedron each observed point falls in
#   and calculate the corresponding bary centric coordinates.
# Inputs:
# (1) Z: Location of the observed points???
# (2) V: The \code{N} by three matrix of vertices of a tetrahedron, where \code{N} is the number of vertices. Each row is the coordinates for a vertex.
# (3) Th: The tetrahedral partition matrix of dimension \code{nT} by four, where \code{nT} is the number of tetrahedrons in the partition. Each row is the indices of vertices in \code{V}.
# Outputs: A list of vector and matrix, including:
# (1) ind.VT: A vector that represents the tetrahedron each observed point falls in.
# (2) lam: The bary centric coordinates for each observed point.
pointLocation3D <- function (Z, V, Th) {
  Z = as.matrix(Z) #Z <- as.matrix(Z[!is.na(Z)]); 
  n <- nrow(Z)
  nT <- nrow(Th)
  ind.VT <- matrix(NaN, nrow = n)
  lam <- matrix(NaN, nrow = n, ncol = 4)
  tol.pl <- eps(1)
  for (i in 1:n) {
    for (j in nT:1) {
      A <- V[Th[j, 1], ]
      B <- V[Th[j, 2], ]
      C <- V[Th[j, 3], ]
      D <- V[Th[j, 4], ]
      Det.0 <- det(cbind(rbind(A, B, C, D),matrix(1, nrow = 4)))
      Det.1 <- det(cbind(rbind(Z[i, ], B, C, D), matrix(1, nrow = 4)))
      Det.2 <- det(cbind(rbind(A, Z[i, ], C, D), matrix(1, nrow = 4)))
      Det.3 <- det(cbind(rbind(A, B, Z[i, ], D), matrix(1, nrow = 4)))
      Det.4 <- det(cbind(rbind(A, B, C, Z[i, ]), matrix(1, nrow = 4)))
      
      if (Det.0 > 0) {
        if ((Det.1 > Det.0) | (Det.2 > Det.0) | (Det.3 > Det.0) | (Det.4 > Det.0)) {
          next
        } else if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
          ind.VT[i] <- j
          break
        } else if ((Det.1 < 0) & (abs(Det.1) <= tol.pl)) {
          if ((Det.2 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.2 < 0) & (abs(Det.2) <= tol.pl) & (Det.3 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl) & (Det.2 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.2 >= 0) & (Det.3 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.2 < 0) & (abs(Det.2) <= tol.pl)) {
          if ((Det.1 >= 0) & (Det.3 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl) & (Det.1 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.1 >= 0) & (Det.3 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.3 < 0) & (abs(Det.3) <= tol.pl)) {
          if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.4 >= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl) & (Det.1 >= 0) & (Det.2 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.4 < 0) & (abs(Det.4) <= tol.pl)) {
          if ((Det.1 >= 0) & (Det.2 >= 0) & (Det.3 >= 0)) {
            ind.VT[i] <- j
            break
          }
        }
      } else if (Det.0 < 0){
        if ((abs(Det.1) >= abs(Det.0)) | (abs(Det.2) >= abs(Det.0)) | (abs(Det.3) >= abs(Det.0)) | (abs(Det.4) >= abs(Det.0))) {
          next
        } else if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
          ind.VT[i] <- j
          break
        } else if ((Det.1 > 0) & (Det.1 <= tol.pl)) {
          if ((Det.2 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.2 > 0) & (Det.2 <= tol.pl) & (Det.3 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.3 > 0) & (Det.3 <= tol.pl) & (Det.2 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.2 >= 0) & (Det.3 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.2 > 0) & (Det.2 <= tol.pl)) {
          if ((Det.1 <= 0) & (Det.3 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.3 > 0) & (Det.3 <= tol.pl) & (Det.1 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.1 >= 0) & (Det.3 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.3 > 0) & (Det.3 <= tol.pl)) {
          if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.4 <= 0)) {
            ind.VT[i] <- j
            break
          } else if ((Det.4 > 0) & (Det.4 <= tol.pl) & (Det.1 >= 0) & (Det.2 >= 0)) {
            ind.VT[i] <- j
            break
          }
        } else if ((Det.4 > 0) & (Det.4 <= tol.pl)) {
          if ((Det.1 <= 0) & (Det.2 <= 0) & (Det.3 <= 0)) {
            ind.VT[i] <- j
            break
          }
        }
      }
    }
    if (ind.VT[i]!="NaN") {
      lam[i, 1] <- Det.1 / Det.0
      lam[i, 2] <- Det.2 / Det.0
      lam[i, 3] <- Det.3 / Det.0
      lam[i, 4] <- Det.4 / Det.0
    }
  }
  pointLocation3D.list <- list(ind.VT = ind.VT, lam = lam)
  
  return(pointLocation3D.list)
}

######################################################################
# pointLocation3D (Z, V, Th)
# Function: Find the index of tetrahedron each observed point falls in
#   and calculate the corresponding bary centric coordinates.
# Inputs:
# (1) Z: Location of the observed points???
# (2) V: The \code{N} by three matrix of vertices of a tetrahedron, where \code{N} is the number of vertices. Each row is the coordinates for a vertex.
# (3) Th: The tetrahedral partition matrix of dimension \code{nT} by four, where \code{nT} is the number of tetrahedrons in the partition. Each row is the indices of vertices in \code{V}.
# Outputs: A list of vector and matrix, including:
# (1) ind.VT: A vector that represents the tetrahedron each observed point falls in.
# (2) lam: The bary centric coordinates for each observed point.
pointLocation3D.parLapply.1 <- function (Z, V, Th) {
  Z <- as.matrix(Z) 
  ind.VT_0 <- matrix(NaN, nrow = 1)
  lam_0 <- matrix(NaN, nrow = 1, ncol = 4)
  tol.pl <- eps(1)
  
  cpu.cores <- detectCores()
  cl <- makeCluster(cpu.cores)

  # load library(pracma) into all nodes 
  # clusterEvalQ(cl, library(pracma))
  
  # Build global variables
  V <- V
  Th <- Th
  d <- d
  r <- r
  varlist <- c("V", "Th", "d", "r")
  clusterExport(cl, varlist, envir = .GlobalEnv)
  
  # Use global variables at all nodes
  PL.results.all <- parLapply(cl = cl, 1:nrow(Z), fun = pointLocation3D.worker.parLapply, 
                              ind.VT_0 = ind.VT_0, lam_0 = lam_0, tol.pl = tol.pl, Z = Z, Th = Th)
  stopCluster(cl)
  #computing.Pointlocation.parallel.time <- proc.time()[3] - pt.1
  
  # combine results from workers ----
  ind.VT <- matrix(NaN, nrow = nrow(Z))
  lam <- matrix(NaN, nrow = nrow(Z), ncol = 4)
  for (i in 1:nrow(Z)) {
    lam[i, ] <- PL.results.all[[i]]$lam_0
    ind.VT[i, ] <- PL.results.all[[i]]$ind.VT_0
  }
  
  pointLocation3D.list <- list(ind.VT = ind.VT, lam = lam)
  return(pointLocation3D.list)
}

######################################################################
# pointLocation3D (Z, V, Th)
# Function: Find the index of tetrahedron each observed point falls in
#   and calculate the corresponding bary centric coordinates.
# Inputs:
# (1) Z: Location of the observed points???
# (2) V: The \code{N} by three matrix of vertices of a tetrahedron, where \code{N} is the number of vertices. Each row is the coordinates for a vertex.
# (3) Th: The tetrahedral partition matrix of dimension \code{nT} by four, where \code{nT} is the number of tetrahedrons in the partition. Each row is the indices of vertices in \code{V}.
# Outputs: A list of vector and matrix, including:
# (1) ind.VT: A vector that represents the tetrahedron each observed point falls in.
# (2) lam: The bary centric coordinates for each observed point.
pointLocation3D.parLapply.2 <- function (Z1, V, Thi) {
  Z1 <- as.matrix(Z1) #Z <- as.matrix(Z[!is.na(Z)]); 
  V <- V
  Thi <- Thi
  ind.VT_0 <- matrix(NaN, nrow = 1)
  lam_0 <- matrix(NaN, nrow = 1, ncol = 4)
  tol.pl <- eps(1)
  
  cpu.cores <- detectCores()
  cl <- makeCluster(cpu.cores)
  varlist <- c("V", "Th", "d", "r")
  clusterExport(cl, varlist, envir = .GlobalEnv)

  # load library(pracma) into all nodes 
  #clusterEvalQ(cl, library(pracma))
  #clusterEvalQ(cl, library(parallel))
  # Build global variables
  ###V <- V
  ###Th <- Th
  ###d <- d
  ###r <- r
  #Z <- as.matrix(Z)
  
  ###varlist <- c("V", "Th", "d", "r")
  ###clusterExport(cl, varlist, envir = .GlobalEnv)
  
  # Use global variables at all nodes
  PL.results.all <- parLapply(cl = cl, 1:nrow(Z1), fun = pointLocation3D.worker.parLapply, 
                              ind.VT_0 = ind.VT_0, lam_0 = lam_0, tol.pl = tol.pl, Z = Z1, Th = Thi)
  ###stopCluster(cl)
  #computing.Pointlocation.parallel.time <- proc.time()[3] - pt.1
  
  # combine results from workers ----
  ind.VT <- matrix(NaN, nrow = nrow(Z1))
  lam <- matrix(NaN, nrow = nrow(Z1), ncol = 4)
  for (i in 1:nrow(Z1)) {
    lam[i, ] <- PL.results.all[[i]]$lam_0
    ind.VT[i, ] <- PL.results.all[[i]]$ind.VT_0
  }
  
  pointLocation3D.list <- list(ind.VT = ind.VT, lam = lam)
  return(pointLocation3D.list)
}

