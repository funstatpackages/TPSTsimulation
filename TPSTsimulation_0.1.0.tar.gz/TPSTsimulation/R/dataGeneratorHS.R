#library(rgl)
#library(plot3D)

dataGeneratorHS <- function(Z, ind.in, sig = 5, missing = 0, seed = 2023) {
  r0 <- 0.1; r <- 0.5; q <- pi * r/2; b <- 1; l <- 3;
  set.seed(seed)
  xx <- matrix(Z[, 1], ncol = 1)    
  yy <- matrix(Z[, 2], ncol = 1)    
  zz <- matrix(Z[, 3], ncol = 1) 
  n <- nrow(xx)
  mu <- matrix(NaN, nrow = n)
  a <- matrix(0, nrow = n, ncol = 1)
  d <- matrix(0, nrow = n, ncol = 1)
  ind.all <- matrix(seq(1, n, by = 1), nrow = 1)
  ind.out <- setdiff(ind.all, ind.in) 

  # Part 1
  ind <- (xx >= 0) & (yy > 0)
  a[ind] <- q + xx[ind]
  d[ind] <- yy[ind] - r
  
  # Part 2
  ind <- (xx >= 0) & (yy <= 0)
  a[ind] <- -q - xx[ind]
  d[ind] <- -r - yy[ind]
  
  # Part 3
  ind <- (xx < 0)
  a[ind] <- -atan(matrix(sweep(matrix(yy[ind], ncol = 1), 1, matrix((xx[ind]), ncol = 1), "/"), nrow=1)) * r
  d[ind] <- sqrt((xx[ind])^2 + yy[ind]^2) - r
  
  ind = (abs(d) > r - r0) | (xx > l & (xx - l)^2 + d^2 > (r - r0)^2);
  
  type = 1
  if (type == 1) {
    mu <- sweep((a * b + d^2), 1, (2 - zz^2), "*")
  } else if (type == 2) {
    mu <- sweep((a * b + d^2), 1, sin(pi * zz), "*")
  } else if (type == 3) {
    mu <- sweep((a * b + d^2), 1, cos(pi * zz), "*")
  } else if (type == 4) {
    mu <- sweep((a * b + d^2), 1, exp(-8 * zz^2), "*")
  }
  
  mu[ind == TRUE] <- NA;
  mu[ind.out] <- NA;
  ind.na = 1:n; ind.na = ind.na[is.na(mu)];
  # scatter3D(xx, yy, zz, colvar = mu, pch = 20, radius = 0.1)
  
  # sig = max(mu, na.rm = TRUE)/(10^(psnr/20))
  psnr = 20 * log(max(mu, na.rm = TRUE), base = 10) - 10 * log(sig^2, base = 10)
  e <- matrix(rnorm(n, mean = 0, sd = sig), ncol = 1)
  Y <- mu + e
  
  # Y = mu
  if (missing == 1) {
    Y[(xx <= -0.3 & xx >= -0.7 & yy <= 0.4 & yy >= -0.4)] = NA
  } else if (missing == 2) {
    Y[(xx <= 2.0 & xx >= 1.0 & zz <= 0.4 & zz >= -0.4)] = NA
  } else if (missing == 3) {
    Y[(yy <= -0.45 & yy >= -0.55 & zz <= 0.4 & zz >= -0.4)] = NA
    Y[(yy <= 0.55 & yy >= 0.45 & zz <= 0.4 & zz >= -0.4)] = NA
  }
  # scatter3D(xx, yy, zz, colvar = Y, pch = 20, radius = 0.1)
  # plot3d(xx, yy, zz, col = v + abs(min(v, na.rm = TRUE)) + 0.1, type = 's', radius = 0.1)
  dataHS.list <- list(Z = Z, mu = mu, Y = Y, sig = sig, psnr = psnr, ind.na = ind.na)
}
