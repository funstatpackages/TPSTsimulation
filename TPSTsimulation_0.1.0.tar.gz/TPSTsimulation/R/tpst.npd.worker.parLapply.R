tpst.npd.worker.parLapply <- function(i, Zi, Yi, npara, TV.sparse, lambda, ss) {
  #source("basis3D.R")
  #source("basis3DFns.R")
  #source("dataGenerator.R")
  #source("energyM3D.R")
  #source("energy3DFns.R")
  #source("smoothness3D.R")
  #source("smoothness3DFns.R")
  #source("thdata.R")
  #source("bary.R")
  #source("qrH.R")
  #source("TPST_est.R")
  #source("findNabr.R")
  #source("insideVT.R")
  #print(i)
  
  #if (ss > 2000) {
  #  PL.worker.parLapply <<- 2 # for pointLocation3D.parLapply.2
  #} else {
  #  PL.worker.parLapply <<- 0 # for pointLocation3D.R (w/o parallel)
  #}
  
  ind_gamma <- ((i - 1) * npara + 1) : (i * npara)
  Th0 <- matrix(Th[i, ], nrow = 1)
  findNabr.list <- findNabr(Th0, V, Th, TV.sparse, nl = 1)
  Thi <- as.matrix(findNabr.list$Th1)
  Hi <- smoothness3D(V, Thi, d, r) # H is the smoothness condition matrix
  Hi.full <- as.matrix(Hi)
  Q2i <- qrH(Hi.full)
  
  Ki <- energyM3D(V, Thi, d) # energy matrix
  indi <- insideVT(V, Thi, Zi)
  Y1 <- matrix(Yi[indi == 1], ncol = 1); Z1 <- Zi[indi == 1, ]; 
  
  # if (ss > 2000) {
  #  basis3D.list <- basis3D(V, Thi, d, r, Z1, PL.worker.parLapply = 2) # for pointLocation3D.parLapply.2
  # } else {
    basis3D.list <- basis3D(V, Thi, d, r, Z1, PL.worker.parLapply = 0) # for pointLocation3D.R (w/o parallel)
  #}
  
  Bi <- basis3D.list$B
  TPST_est.list <- TPST_est(Bi, Q2i, Ki, Y1, lambda)
  gammai <- TPST_est.list$gamma
  Io <- matrix(1, nrow = dim(Thi)[1], ncol = dim(Thi)[2])
  jj <- which(colSums(abs(t(Thi) - t(cbind(Th0[1,1] * Io[, 1], Th0[1, 2] * Io[, 2], Th0[1, 3] * Io[, 3], Th0[1, 4] * Io[, 4])))) == 0)
  #gamma_ddc[, i] <- gammai[min(((j-1) * npara + 1)):min((j * npara))]
  
  #####
  gamma_ddc_0 <- gammai[min(((jj-1) * npara + 1)):min((jj * npara))]
  return(gamma_ddc_0)
}
